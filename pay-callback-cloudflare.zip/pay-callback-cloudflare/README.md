# Market Digital Payment Callback (Cloudflare Pages)

Template website + API endpoints for Cloudflare Pages.

## Routes
- `/` : landing page
- `/api/health` : service health check (GET)
- `/api/callback` : callback info (GET)
- `/api/webhook` : webhook receiver (POST; HMAC-SHA256 using `X-Signature`)

## Deploy via GitHub
1. Create a GitHub repository and upload/push this project.
2. Cloudflare Dashboard → Workers & Pages → Create → Pages → Connect to Git.
3. Select repository.
4. Framework preset: **None**.
5. Build command: leave blank (no build required).
6. Build output directory: `public`.
7. Deploy.
8. Pages project → Settings → Variables and Secrets → add secret `WEBHOOK_SECRET` (your gateway's webhook signing secret).
9. Configure gateway webhook URL to `https://YOUR-DOMAIN/api/webhook`.
10. Attach custom domain in Pages project settings, e.g. `pay.digikita.id`.

## Important
- This template's signature header/format is generic. Your payment provider may use a different signature header, signing algorithm, or signature payload. Adapt `functions/api/webhook.js` to the provider's official specification before production use.
- Webhook currently validates signature, logs selected fields, and acknowledges. It does not persist orders or notify WhatsApp bot yet.
- Do not store API keys in GitHub or frontend files. Use Cloudflare Secrets/Variables.
- Client redirect/callback is not proof of payment; trust verified webhook or provider-side status verification.
