const encoder = new TextEncoder();

async function verifyHmac(rawBody, signature, secret) {
  if (!signature || !secret) return false;
  // Expected signature format: hex HMAC-SHA256 of the raw request body.
  const key = await crypto.subtle.importKey("raw", encoder.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const digest = new Uint8Array(await crypto.subtle.sign("HMAC", key, encoder.encode(rawBody)));
  const hex = Array.from(digest, b => b.toString(16).padStart(2, "0")).join("");
  const provided = signature.replace(/^sha256=/i, "").trim().toLowerCase();
  if (hex.length !== provided.length) return false;
  let mismatch = 0;
  for (let i = 0; i < hex.length; i++) mismatch |= hex.charCodeAt(i) ^ provided.charCodeAt(i);
  return mismatch === 0;
}

export async function onRequest({ request, env }) {
  if (request.method !== "POST") return new Response("Method Not Allowed", { status: 405, headers: { Allow: "POST" } });
  const rawBody = await request.text();
  if (rawBody.length > 1024 * 100) return Response.json({ ok: false, error: "Payload too large" }, { status: 413 });

  // Gateway-specific signature header may need adjustment. This template uses X-Signature.
  const signature = request.headers.get("X-Signature") || request.headers.get("x-signature");
  if (!env.WEBHOOK_SECRET) return Response.json({ ok: false, error: "Webhook secret is not configured" }, { status: 500 });
  const valid = await verifyHmac(rawBody, signature, env.WEBHOOK_SECRET);
  if (!valid) return Response.json({ ok: false, error: "Invalid signature" }, { status: 401 });

  let payload;
  try { payload = JSON.parse(rawBody); }
  catch { return Response.json({ ok: false, error: "Invalid JSON" }, { status: 400 }); }

  // TODO: Map fields/status from your gateway payload and connect your bot/order handler.
  // Never mark an order paid solely from an unverified client redirect/callback.
  console.log("Verified payment webhook received", {
    event: payload.event || payload.type || "unknown",
    order_id: payload.order_id || payload.reference || payload.transaction_id || null,
    status: payload.status || payload.payment_status || null,
  });

  return Response.json({ ok: true, received: true });
}
