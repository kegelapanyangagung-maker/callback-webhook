export async function onRequest({ request }) {
  if (request.method !== "GET") return new Response("Method Not Allowed", { status: 405, headers: { Allow: "GET" } });
  return Response.json({ ok: true, message: "Callback endpoint aktif. Endpoint webhook untuk POST: /api/webhook" });
}
