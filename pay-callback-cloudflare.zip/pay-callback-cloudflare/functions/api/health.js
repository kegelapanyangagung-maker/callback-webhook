export async function onRequest() {
  return Response.json({ ok: true, service: "market-digital-payment-callback", platform: "Cloudflare Pages", timestamp: new Date().toISOString() });
}
